import { Box, Image, Icon,IconButton, Text, Heading, VStack, FormControl, Input, Link, Button, HStack, Center, NativeBaseProvider,StatusBar } from "native-base";
import React from "react";
import { useState} from 'react';
import { MaterialIcons } from '@expo/vector-icons'; 
import { AntDesign } from '@expo/vector-icons'; 
import {auth} from '../src/fb/firebaseauth';
import { signInWithEmailAndPassword } from "firebase/auth";
import { UserCredential } from "firebase/auth";
import { useNavigation } from '@react-navigation/native';

const SignInForm= () => {
  const navigation = useNavigation();
  const [user,setUser] = useState('');
  const [password,setPassword] = useState('');

  const handleLogin=() => {
     signInWithEmailAndPassword(auth,user,password)
    .then(userCredential => {
      const user=userCredential.user;
      console.log('logged in with:',user.email, user.uid);
      navigation.navigate('HomePaciente',{
        uid:user.uid,
        email: user.email,
      });
    }).catch(error => alert(error.message));
  }

  return <Center w="100%">
      <Box safeArea p="2" py="8" w="100%" maxW="400" alignContent={'flex-start'}>
        <Heading size="lg" textAlign={'center'} fontSize={"30"} fontWeight="900" color="coolGray.800" _dark={{
        color: "warmGray.50"
      }}>
          Inicio de sesión
        </Heading>
        <VStack space={3} mt="2">
          <FormControl>
            <FormControl.Label>Correo Electrónico</FormControl.Label>
            <Input
              InputLeftElement={<Icon as={<MaterialIcons name="email"/>} size={6} ml="4" color="deepskyblue"/>}
              placeholder="Correo Electrónico"
              size="xl"
              variant="rounded"
              type="email"
              value={user}
              onChangeText={text => setUser(text)}
            />
          </FormControl>
          <FormControl>
            <FormControl.Label style={{fontSize:'40'}}>Contraseña</FormControl.Label>
            <Input 
            InputLeftElement={<Icon as={<AntDesign name="lock"/>} size={7} ml="4" color="deepskyblue"/>}
            type="password" placeholder="Contraseña" size="xl"variant="rounded"
            value={password}
            onChangeText={text => setPassword(text)} />
            <Link _text={{
            fontSize: "xs",
            fontWeight: "500",
            color: "indigo.500"
          }} alignSelf="flex-end" mt="1">
              Olvidaste tu contraseña?
            </Link>
          </FormControl>
          <Button onPress={handleLogin} mt="2" colorScheme="indigo">
            Iniciar Sesión
          </Button>
        </VStack>
        <Button mt="2" colorScheme="indigo" title='REGISTRARSE' onPress={()=>navigation.navigate('SignUpScreen')} style={{width:385}}>Registrarme!</Button>
          <Button mt="2" colorScheme="indigo" title='REGISTRARSE' style={{width:385}}>Prueba</Button>
          <Button mt="2" backgroundColor={"amber.600"} style={{width:385}}>PACIENTE</Button>
          <Button mt="2" backgroundColor={"teal.500"} style={{width:385}}>DOCTOR</Button>
      </Box>
    </Center>;
};
export default function SignInScreen({navigation}){
  return(
    <NativeBaseProvider>
        <Center marginTop={100}>
          <Image source={require('../src/images/icono_v4.png')} size="400" alt="HealthCore"/>
          <SignInForm/>
        </Center>
    </NativeBaseProvider>
  ); 
}