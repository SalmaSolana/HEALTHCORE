import React from "react";
import { useState } from 'react';
import { Image } from "react-native";
import { AntDesign } from '@expo/vector-icons';
import { MaterialIcons } from '@expo/vector-icons';
import { EvilIcons } from '@expo/vector-icons';
import { auth } from '../src/fb/firebaseauth';
import { createUserWithEmailAndPassword } from "firebase/auth";
import { UserCredential } from "firebase/auth";
import { useNavigation } from '@react-navigation/native';
import {database} from './../src/fb/firebase';
import {collection, addDoc, doc} from 'firebase/firestore';
import { Icon, Box, Heading, VStack, FormControl, Input, Button, Center, NativeBaseProvider, IconButton, StatusBar, HStack, Text } from "native-base";

const SignUpForm = () => {
  const navigation = useNavigation();
  const [user, setUser] = useState('');
  const [password, setPassword] = useState('');
  const [passwordV, setPasswordV] = useState('');

  const handleSignUp = () => {
    if (password === passwordV) {
      createUserWithEmailAndPassword(auth, user, password)
        .then(userCredential => {
          const user = userCredential.user;
          console.log('logged in with:', user.email, user.uid);
          const newInput =doc(database,'Paciente',)

          navigation.navigate('HomePaciente', {
            uid: user.uid,
            email: user.email,
          });
        }).catch(error => alert(error.message));
    }else{
      alert('Las contraseñas no coinciden');
    }
  }

  return <Center w="100%">
    <Box safeArea p="2" w="100%" maxW="400" py="8" alignContent={'flex-start'}>
      <Heading size="lg" textAlign={'center'} fontSize={"30"} color="coolGray.800" _dark={{ color: "warmGray.50" }} fontWeight="bold">Registro de Usuario</Heading>
      <VStack space={3} mt="5">
        <FormControl>
          <Input
            InputLeftElement={<Icon as={<MaterialIcons name="email" />} size={8} ml="5" color="deepskyblue" />}
            placeholder="Correo Electrónico"
            size="xl"
            variant="rounded"
            value={user}
            onChangeText={text => setUser(text)}
          />
        </FormControl>
        <FormControl>
          <Input
            InputLeftElement={<Icon as={<AntDesign name="lock" />} size={9} ml="5" color="deepskyblue" />}
            type="password" placeholder="Contraseña" size="xl" variant="rounded"
            value={password}
            onChangeText={text => setPassword(text)} />
        </FormControl>
        <FormControl>
          <Input
            InputLeftElement={<Icon as={<AntDesign name="lock" />} size={9} ml="5" color="deepskyblue" />}
            type="password" placeholder=" Verificar Contraseña" size="xl" variant="rounded" value={passwordV}
            onChangeText={text => setPasswordV(text)} />
        </FormControl>
      </VStack>
      <Button mt="2" colorScheme="indigo" title='REGISTRARSE' onPress={handleSignUp} style={{ width: 385 }}>Registrarse!</Button>
    </Box>
  </Center>;
};


export default function SignUpScreen({ navigation }) {
  return (
    <NativeBaseProvider>
      <Center>
        <Image source={require('../src/images/icono_v4.png')} style={{ width: 300, height: 300, marginTop: 100 }} />
        <SignUpForm />
      </Center>
    </NativeBaseProvider>
  );
}