import React from 'react';
import useSyncExternalStore from 'react';
import { MaterialIcons } from '@expo/vector-icons';
import { HStack, IconButton, Icon, Text, NativeBaseProvider, Center, Box, Image, StatusBar, Button } from "native-base";

function AppBar() {
  return <>
    <StatusBar bg="#3700B3" barStyle="light-content" />
    <Box safeAreaTop bg="#6200ee" />
    <HStack bg="#6200ee" px="1" py="3" justifyContent="space-between" alignItems="center" w="100%">
      <HStack alignItems="center">
        <Text color="white" fontSize="20" fontWeight="bold" style={{ marginLeft: 10 }}>
          Contactos de Emergencia
            </Text>
      </HStack>
      <HStack>
        <IconButton icon={<Icon as={MaterialIcons} name="more-vert" size="sm" color="white" />} />
      </HStack>
    </HStack>
  </>;
}

function Form() {
  return (<>

    <Center >
      <Image source={require('../../../src/images/qr.png')} style={{ width: 300, height: 300 }} />

    </Center>
  </>)
};

export default function LectorQR({ navigation }) {
  return (
    <NativeBaseProvider>
      <AppBar />
      <Center>
        <Text mt="5" color="grey" fontSize="24.88" fontWeight="bold" style={{ marginLeft: 10 }}>
          LECTOR CÓDIGO QR
      </Text >
        <Text  color="grey" fontSize="15" fontWeight="bold" style={{ marginLeft: 10 }}>
      </Text >
      <Box borderWidth={1} borderColor="light.400" alignSelf="center" bg="white" marginTop={"5px"} paddingBottom={"5px"} _text={{ fontWeight: "medium", color: "warmGray.50", letterSpacing: "lg" }} style={{ width: "85%" }}>
        <Form />
      </Box>
      <Button mt="10" colorScheme="muted" title='ESCANEAR' onPress={() => navigation.navigate('')} style={{ width: 300 }}>ESCANEAR</Button>
          </Center>
      </NativeBaseProvider >
      );
}