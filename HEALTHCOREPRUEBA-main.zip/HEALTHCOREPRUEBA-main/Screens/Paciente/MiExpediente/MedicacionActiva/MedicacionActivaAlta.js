import React, { useState } from 'react';
import { useNavigation } from '@react-navigation/native';
import { MaterialIcons } from '@expo/vector-icons'; 
import { FontAwesome } from '@expo/vector-icons'; 
import { AntDesign } from "@expo/vector-icons";
import { VStack, Fab, HStack, IconButton, Icon, Text, Radio, FormControl, CheckIcon, NativeBaseProvider, Input, Center, Box, StatusBar, Heading, Select,Stack, Button, Image} from "native-base";


function AppBar() {
    return <>
        <StatusBar bg="#3700B3" barStyle="light-content" />
        <Box safeAreaTop bg="#6200ee" />
        <HStack bg="#6200ee" px="1" py="3" justifyContent="space-between" alignItems="center" w="100%">
          <HStack alignItems="center">
            <Text color="white" fontSize="20" fontWeight="bold" style={{marginLeft:10}}>Incidentes Recientes</Text>
          </HStack>
          <HStack>
            <IconButton icon={<Icon as={MaterialIcons} name="more-vert" size="sm" color="white" />} />
          </HStack>
        </HStack>
      </>;
  }

  function Form(){
    const navigation = useNavigation();
    
    return(<>
      <VStack space={10} alignItems="center">
        <Center w="95%">
          <HStack space="2" alignItems="center">
          <VStack alignItems="center">
            <Text  fontWeight={"bold"} fontSize="lg">Nombre del</Text>            
            <Text  fontWeight={"bold"} fontSize="lg">medicamento:</Text>
          </VStack>  
            <Input multiline fontWeight={"bold"} w={"60%"} h="60" fontSize="xl">Ej. Paracetamol</Input>
          </HStack>
        </Center>
        <Center w="95%">
          <HStack space="2" alignItems="center">            
            <Text  fontWeight={"bold"} fontSize="lg">Motivo:</Text>  
            <Input fontWeight={"bold"} w={"70%"}  h="70" multiline fontSize="xl">Ej. Medicamento Pos Cirugia</Input>
          </HStack>
        </Center>
        <Center w="95%">
          <HStack space="2" alignItems="center">
            <Text fontWeight={"bold"} fontSize="lg">Vía de administración:</Text>
            <FormControl w="60%">
              <Select accessibilityLabel="Frecuencia" size="xl" placeholder="Seleccionar" fontWeight={"bold"} _selectedItem={{ bg: "black", endIcon: <CheckIcon size={3} /> }}>
                <Select.Item label="Oral" value="1" />
                <Select.Item label="Intramuscular" value="2" />
                <Select.Item label="Intravenosa" value="3" />
                <Select.Item label="Subcutanea" value="4" />
                <Select.Item label="Inhalatoria" value="5" />
                <Select.Item label="Trandermica" value="6" />
                <Select.Item label="Nasal" value="7" />
                <Select.Item label="Oftalmica" value="8" />
                <Select.Item label="Ótica" value="9" />
                <Select.Item label="Tópica" value="10" />
                <Select.Item label="Rectal" value="11" />
                <Select.Item label="Vaginal" value="12" />
              </Select>
            </FormControl>
          </HStack>
        </Center>
        <Center w="95%">
          <HStack space="2" alignItems="center">
            <Text fontWeight={"bold"} fontSize="lg">Tipo de medicamento:</Text>
            <FormControl w="60%">
              <Select accessibilityLabel="Frecuencia" size="xl" placeholder="Seleccionar" fontWeight={"bold"} _selectedItem={{ bg: "black", endIcon: <CheckIcon size={3} /> }}>
                <Select.Item label="Capsula" value="1" />
                <Select.Item label="Jarabe" value="2" />
                <Select.Item label="Grajea" value="3" />
                <Select.Item label="Suspención" value="4" />
                <Select.Item label="Aerosol o Nebulizador" value="5" />
                <Select.Item label="Polvo en seco" value="6" />
                <Select.Item label="Parches" value="7" />
                <Select.Item label="Gotas" value="8" />
                <Select.Item label="Pomada" value="9" />
                <Select.Item label="Supositorio" value="10" />
                <Select.Item label="Inyección" value="11" />
                <Select.Item label="Óvulos" value="12" />
              </Select>
            </FormControl>
          </HStack>
        </Center>
        <Center w="95%">
          <HStack space="2" alignItems="center">            
            <Text  fontWeight={"bold"} fontSize="lg">Dosis:</Text>  
            <Input fontWeight={"bold"} w={"70%"}  h="60" multiline fontSize="xl">Ej. 20ml al día</Input>
          </HStack>
        </Center>
        <Button backgroundColor="info.600" width="85%" h="20" title='MODIFICAR' onPress={()=>navigation.navigate('MedicacionActiva')}><Text fontSize={"3xl"} fontWeight="bold" color="white">GUARDAR</Text></Button>
      </VStack>
       </>);}

export default function MedicacionActiva({navigation}){
    return(
      <NativeBaseProvider>
        <AppBar/>
        <Box>
          <Box borderWidth={3} borderRadius="xl" borderColor="info.800" alignSelf="center" bg="white" marginTop={4} width="95%" h="94%">
            <Image marginTop={4} marginBottom={4} source={require('../../../../src/images/MedicacionActiva.png')} size="xl" resizeMode='contain' alignSelf={"center"} alt={"Actividad Fisica"}/>
            <Heading fontSize={"4xl"} marginBottom={"5%"} textAlign="center">Medicamentos y tratamientos que lleva el paciente actualmente</Heading>
            <Heading fontSize={"2xl"} fontStyle="italic" marginBottom={4} textAlign="center">Medicina del paciente</Heading>
            <Form/>
          </Box>
        </Box>
      </NativeBaseProvider>
    );
}