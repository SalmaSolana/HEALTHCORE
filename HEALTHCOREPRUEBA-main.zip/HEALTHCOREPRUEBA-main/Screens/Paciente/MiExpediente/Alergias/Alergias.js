import React from 'react';
import { MaterialIcons } from '@expo/vector-icons'; 
import { FontAwesome } from '@expo/vector-icons'; 
import { AntDesign } from "@expo/vector-icons";
import { VStack, Fab, HStack, IconButton, Icon, Text, FormControl, CheckIcon, NativeBaseProvider, Center, Box, StatusBar, Heading, Select,Stack, Button, Image} from "native-base";

function AppBar() {
  return(<>
    <StatusBar bg="#3700B3" barStyle="light-content" />
    <Box safeAreaTop>
      <HStack bg="info.600" px="1" py="3" justifyContent="space-between" alignItems="center" w="100%">
        <HStack alignItems="center">
          <Text color="white" fontSize="45"  fontWeight="bold" style={{marginLeft:10}}>Alergias</Text>
        </HStack>
        <HStack>
          <IconButton icon={<Icon as={MaterialIcons} name="more-vert" size="2xl" color="white" />} />
        </HStack>
      </HStack>
    </Box>
  </>);
}

  function Form(){
  return(<>
    <VStack space={1} alignItems="center">
      <Center w="95%" h="140px" paddingX={2}>
        <HStack space="3" alignItems="center">
          <Center width={"60%"} height={"100%"} rounded="md">
            <Text fontWeight={"bold"} fontSize="xl" w="100%" h="80%" borderRadius={9} bg="lightBlue.200" style={{ padding: 6 }}>
              Paracetamol. No puedo consumir ningún medicamento con este compuesto.
            </Text>
          </Center>
          <Center width={"30%"} height={"100%"} rounded="md">
            <FormControl>
              <Select accessibilityLabel="Choose Service" fontWeight={"bold"} fontSize={"lg"} placeholder="Alto" isDisabled _selectedItem={{ bg: "black", endIcon: <CheckIcon size={3} /> }} mt="1"></Select>
            </FormControl>
          </Center>
          <Center width={"8%"} height={"100%"}>
            <Icono />
          </Center>
        </HStack>
      </Center>
      {/*NUMERO 2*/}
      <Center w="95%" h="140px" paddingX={2}>
        <HStack space="3" alignItems="center">
          <Center width={"60%"} height={"100%"} rounded="md">
            <Text fontWeight={"bold"} fontSize="xl" w="100%" h="80%" borderRadius={9} bg="lightBlue.200" style={{ padding: 6 }}>
            Polvo.Estornudos y tos.
            </Text>
          </Center>
          <Center width={"30%"} height={"100%"} rounded="md">
            <FormControl>
              <Select accessibilityLabel="Choose Service" fontWeight={"bold"} fontSize={"lg"} placeholder="Moderado" isDisabled _selectedItem={{ bg: "black", endIcon: <CheckIcon size={3} /> }} mt="1"></Select>
            </FormControl>
          </Center>
          <Center width={"8%"} height={"100%"}>
            <Icono />
          </Center>
        </HStack>
      </Center>
      {/*NUMERO 3 */}
      <Center w="95%" h="140px" paddingX={2}>
        <HStack space="3" alignItems="center">
          <Center width={"60%"} height={"100%"} rounded="md">
            <Text fontWeight={"bold"} fontSize="xl" w="100%" h="80%" borderRadius={9} bg="lightBlue.200" style={{ padding: 6 }}>
            Gatos. Ojos hinchados, irritacion en la garganta.
            </Text>
          </Center>
          <Center width={"30%"} height={"100%"} rounded="md">
            <FormControl>
              <Select accessibilityLabel="Choose Service" fontWeight={"bold"} fontSize={"lg"} placeholder="Leve"  isDisabled _selectedItem={{ bg: "black", endIcon: <CheckIcon size={3} /> }} mt="1"></Select>
            </FormControl>
          </Center>
          <Center width={"8%"} height={"100%"}>
            <Icono />
          </Center>
        </HStack>
      </Center>
    </VStack>
  </>);}
  
  const Icono = () => {
    return <Box alignItems="center">
        <IconButton icon={<Icon as={FontAwesome} name="trash-o" size={5} color="black"/>} borderRadius="full" _icon={{
        color: "red.400",
        size: "md"
      }} _hover={{
        bg: "red.400"
      }} _pressed={{
        bg: "red.400"
      }} />
      </Box>;
  };

  const NewButton = () => {
    return <Center>
        <Box width={"100%"} height={"90"} justifyContent={"flex-end"} _dark={{
        bg: "coolGray.200:alpha.20"
      }} _light={{
        bg: "coolGray.200:alpha.20"
      }}>
          <Fab renderInPortal={false} shadow={2} size="lg" icon={<Icon color="white" as={AntDesign} name="plus" size="lg" />} />
        </Box>
      </Center>;
  };

export default function Alergias({navigation}){
    return(
      <NativeBaseProvider>
        <AppBar/>
        <Box>
          <Box borderWidth={3} borderRadius="xl" borderColor="info.800" alignSelf="center" bg="white" marginTop={4} _text={{fontWeight: "medium",color: "warmGray.50",letterSpacing: "lg"}} style={{width:"95%"}}>
            <Image marginTop={4} source={require('../../../../src/images/alergia.png')} resizeMode={"contain"} size={"2xl"} alignSelf={"center"} alt="Alergia"/>
            <Heading marginTop={4} textAlign="center" fontSize={"3xl"} >Alergias registradas del usuario</Heading>
            <Form/>
            <Center>
              <Button colorScheme="blue" size={"lg"} title='MODIFICAR' onPress={()=>navigation.navigate('AlergiasModificar')} style={{width:"85%"}}>MODIFICAR</Button>
            </Center>
            <NewButton />
          </Box>
        </Box>
      </NativeBaseProvider>
    );
}