import React from 'react';
import { MaterialIcons } from '@expo/vector-icons'; 
import { VStack, HStack, IconButton, Icon, Text, FormControl, CheckIcon, NativeBaseProvider, Center, Box, StatusBar, Heading, Select, Button, Input, Image} from "native-base";

function AppBar() {
  return(<>
    <StatusBar bg="#3700B3" barStyle="light-content" />
    <Box safeAreaTop>
      <HStack bg="info.600" px="1" py="3" justifyContent="space-between" alignItems="center" w="100%">
        <HStack alignItems="center">
          <Text color="white" fontSize="45"  fontWeight="bold" style={{marginLeft:10}}>Alergias</Text>
        </HStack>
        <HStack>
          <IconButton icon={<Icon as={MaterialIcons} name="more-vert" size="2xl" color="white" />} />
        </HStack>
      </HStack>
    </Box>
  </>);
}

  function Form(){
    return(<>
    <VStack space={4} alignItems="center" marginY={4}>
      <Center w="95%" h="100">
        <HStack space="2" alignItems="center">
          <Center width={"70%"} height={"100%"} rounded="md">
            <Input w={"100%"} h="100%" placeholder='Describa aquí...'multiline bg={"lightBlue.200"} placeholderTextColor="grey" fontSize={"2xl"}/>
          </Center>
          <Center width={"30%"} height={"100%"} rounded="md">
            <FormControl>
              <Select isDisabled accessibilityLabel="Choose Service" placeholder='Urgente' fontWeight={"bold"} fontSize={"lg"} _selectedItem={{ bg: "black", endIcon: <CheckIcon size={3} /> }} mt="1">
                <Select.Item label="Urgente" value="ux" />
                <Select.Item label="Moderado" value="web" />
                <Select.Item label="Leve" value="cross" />
              </Select>
            </FormControl>
          </Center>
        </HStack>
      </Center>
      {/*NUMERO 2*/}
      <Center w="95%" h="100">
        <HStack space="2" alignItems="center">
          <Center width={"70%"} height={"100%"} rounded="md">
            <Input w={"100%"} h="100%" placeholderTextColor="grey" placeholder='Describa aquí...' multiline bg={"lightBlue.200"} fontSize={"2xl"}/>
          </Center>
          <Center width={"30%"} height={"100%"} rounded="md">
            <FormControl>
              <Select accessibilityLabel="Choose Service" placeholder='Elige' fontWeight={"bold"} fontSize={"lg"} _selectedItem={{ bg: "black", endIcon: <CheckIcon size={3} /> }} mt="1">
                <Select.Item label="Alto" value="ux" />
                <Select.Item label="Moderado" value="web" />
                <Select.Item label="Leve" value="cross" />
              </Select>
            </FormControl>
          </Center>
        </HStack>
      </Center>
      {/*NUMERO 3 */}
      <Center w="95%" h="100">
        <HStack space="2" alignItems="center">
          <Center width={"70%"} height={"100%"} rounded="md">
            <Input w={"100%"} h="100%" placeholderTextColor="grey" placeholder='Describa aquí...'multiline bg={"lightBlue.200"} fontSize={"2xl"}/>
          </Center>
          <Center width={"30%"} height={"100%"} rounded="md">
            <FormControl>
              <Select accessibilityLabel="Choose Service" placeholder='Elige'fontWeight={"bold"} fontSize={"lg"} _selectedItem={{ bg: "black", endIcon: <CheckIcon size={3} /> }} mt="1">
                <Select.Item label="Alto" value="ux" />
                <Select.Item label="Moderado" value="web" />
                <Select.Item label="Leve" value="cross" />
              </Select>
            </FormControl>
          </Center>
        </HStack>
      </Center>
    </VStack>
    </>);
  }

export default function AlergiasAlta({navigation}){
    return(
      <NativeBaseProvider>
        <AppBar/>
        <Box>
          <Box borderWidth={3} borderRadius="xl" borderColor="info.800" alignSelf="center" bg="white" marginTop={4} _text={{fontWeight: "medium",color: "warmGray.50",letterSpacing: "lg"}} style={{width:"95%"}}>
          <Image marginTop={4} source={require('../../../../src/images/alergia.png')} resizeMode={"contain"} size={"2xl"} alignSelf={"center"} alt="Alergia"/>
            <Heading marginTop={4} textAlign="center" fontSize={"3xl"} >Registra todas aquellas alergias que posees. Elige el nivel de gravedad de cada una.</Heading>
            <Form/>
            <Center paddingTop={"15px"}>
              <Button  colorScheme="blue" marginBottom={4} title='GUARDAR' onPress={()=>navigation.navigate('Alergias')} style={{width:"85%"}}>GUARDAR</Button>
            </Center>
          </Box>
        </Box>
      </NativeBaseProvider>
    );
}