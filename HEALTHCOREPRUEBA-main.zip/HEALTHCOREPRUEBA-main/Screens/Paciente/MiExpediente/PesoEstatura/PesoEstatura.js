import React from 'react';
import { MaterialIcons } from '@expo/vector-icons';
import { Image, VStack, HStack, IconButton, Icon, Text, Radio, FormControl, CheckIcon, NativeBaseProvider, Center, Box, StatusBar, Heading, Select, Stack, Button } from "native-base";
import { TextInput, StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  input: {
    height: 120,
    width: 300,
    borderWidth: 1,
    padding: 5,
    borderRadius: 8,
  }
});

function AppBar() {
  return <>
    <StatusBar bg="#3700B3" barStyle="light-content" />
    <Box safeAreaTop bg="#6200ee" />
    <HStack bg="#6200ee" px="1" py="3" justifyContent="space-between" alignItems="center" w="100%">
      <HStack alignItems="center">
        <Text color="white" fontSize="20" fontWeight="bold" style={{ marginLeft: 10 }}>Peso y Estatura</Text>
      </HStack>
      <HStack>
        <IconButton icon={<Icon as={MaterialIcons} name="more-vert" size="sm" color="white" />} />
      </HStack>
    </HStack>
  </>;
}

function Form() {
  return (<>
    <VStack space={2} alignItems="center">
      {/*PESO*/}
      <Center w="95%" h="140px">
        <HStack space="2" alignItems="center">
          <Center width={"70%"} height={"100%"} rounded="md">
            <Box borderRadius={9} bg="lightBlue.200">
              <Text fontWeight={"bold"} fontSize="lg" style={{ padding: 6 }}>
                Peso:
              </Text>
            </Box>
          </Center>
          <Center width={"70%"} height={"100%"} rounded="md">
            <Box borderRadius={9} bg="lightBlue.200">
              <TextInput style={styles.input} multiline numberOfLines={5} placeholder="Exprese en kg..." />
            </Box>
          </Center>
        </HStack>
      </Center>
      {/*ESTATURA*/}
      <Center w="95%" h="140px">
        <HStack space="2" alignItems="center">
          <Center width={"70%"} height={"100%"} rounded="md">
            <Box borderRadius={9} bg="lightBlue.200">
              <Text fontWeight={"bold"} fontSize="lg" style={{ padding: 6 }}>
                Estatura:
              </Text>
            </Box>
          </Center>
          <Center width={"70%"} height={"100%"} rounded="md">
            <Box borderRadius={9} bg="lightBlue.200">
              <TextInput style={styles.input} multiline numberOfLines={5} placeholder="Exprese en cm..." />
            </Box>
          </Center>
        </HStack>
      </Center>
    </VStack></>
  );
}

function FormPesoIdeal() {
  return (<>
    <VStack space={1} alignItems="center">
      {/*PESO*/}
      <Center w="95%" h="140px">
        <HStack space="2" alignItems="center">
          <Center width={"70%"} height={"100%"} rounded="md">
            <Box borderRadius={9} bg="lightBlue.200">
              <Text fontWeight={"bold"} fontSize="lg" style={{ padding: 6 }}>
                Sexo:
              </Text>
            </Box>
          </Center>
          <Center width={"70%"} height={"100%"} rounded="md">
            <Box borderRadius={9} bg="lightBlue.200">
              <RadioButton />
            </Box>
          </Center>
        </HStack>
      </Center>
    </VStack></>
  );
}

const RadioButton = () => {
  const [value, setValue] = React.useState("one");
  return <Radio.Group name="myRadioGroup" accessibilityLabel="Sexo" value={value} onChange={nextValue => {
    setValue(nextValue);
  }}>
    <Radio value="Fem" my={1}>
      Femenino
    </Radio>
    <Radio value="Masc" my={1}>
      Masculino
    </Radio>
  </Radio.Group>;
};


export default function PesoEstatura({navigation}) {
  return (
    <NativeBaseProvider>
      <AppBar />
      <Box>
        <Box borderWidth={3} borderRadius="xl" borderColor="info.800" alignSelf="center" bg="white" marginTop={"5px"} paddingBottom={"5px"} _text={{ fontWeight: "medium", color: "warmGray.50", letterSpacing: "lg" }} style={{ width: "95%" }}>
          <Image source={require('../../../../src/images/PesoyEstatura.png')} size="2xl" alignSelf={"center"} alt="Alergia" />
          <Heading size="2xl" textAlign="center">Registro Estatura y Peso</Heading>
          <Form />
          <Center>
            <Button colorScheme="indigo" title='GUARDAR' onPress={() => navigation.navigate('PesoEstatura')} style={{ width: "85%" }}>GUARDAR</Button>
          </Center>
        </Box>
      </Box>
      <Box>
        <Box borderWidth={3} borderRadius="xl" borderColor="info.800" alignSelf="center" bg="white" marginTop={"5px"} paddingBottom={"5px"} _text={{ fontWeight: "medium", color: "warmGray.50", letterSpacing: "lg" }} style={{ width: "95%" }}>
          <Heading size="2xl" textAlign="center">Peso Ideal</Heading>
          <FormPesoIdeal />
          <Center>
            <Button colorScheme="indigo" title='CALCULAR' onPress={() => navigation.navigate('PesoEstatura')} style={{ width: "85%" }}>CALCULAR</Button>
          </Center>
        </Box>
      </Box>
    </NativeBaseProvider>
  );
}