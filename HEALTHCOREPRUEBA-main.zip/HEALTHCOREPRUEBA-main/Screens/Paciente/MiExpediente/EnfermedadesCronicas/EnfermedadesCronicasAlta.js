import React from 'react';
import { MaterialIcons } from '@expo/vector-icons'; 
import { VStack, HStack, IconButton, Input,Image, Icon, Text, NativeBaseProvider, Center, Box, StatusBar, Heading, Button} from "native-base";
function AppBar() {
  return(<>
    <StatusBar bg="#3700B3" barStyle="light-content" />
    <Box safeAreaTop>
      <HStack bg="info.600" px="1" py="3" justifyContent="space-between" alignItems="center" w="100%">
        <HStack alignItems="center">
          <Text color="white" fontSize="45"  fontWeight="bold" style={{marginLeft:10}}>Enfermedades Cronicas</Text>
        </HStack>
        <HStack>
          <IconButton icon={<Icon as={MaterialIcons} name="more-vert" size="2xl" color="white" />} />
        </HStack>
      </HStack>
    </Box>
  </>);
}

  function Form(){
    return(<>
      <VStack space={4} alignItems="center" marginY={4}>
        <Input  placeholder={"Ingresa el Nombre de la enfermedad y una breve descripción"}  w="85%" h="100" multiline bg={"lightBlue.200"} placeholderTextColor="grey" fontStyle={"italic"} fontSize={"2xl"}/>
        <Input  placeholder={"Ingresa el Nombre de la enfermedad y una breve descripción"}  w="85%" h="100" multiline bg={"lightBlue.200"} placeholderTextColor="grey" fontStyle={"italic"}  fontSize={"2xl"}/>
        <Input  placeholder={"Ingresa el Nombre de la enfermedad y una breve descripción"}  w="85%" h="100" multiline bg={"lightBlue.200"} placeholderTextColor="grey" fontStyle={"italic"}  fontSize={"2xl"}/>
        <Input  placeholder={"Ingresa el Nombre de la enfermedad y una breve descripción"}  w="85%" h="100" multiline bg={"lightBlue.200"} placeholderTextColor="grey" fontStyle={"italic"}  fontSize={"2xl"}/>
      </VStack></>
    );
  }

export default function EnfermedadesCronicasAlta({navigation}){
    return(
      <NativeBaseProvider>
        <AppBar/>
        <Box>
          <Box borderWidth={3} borderRadius="xl" borderColor="info.800" alignSelf="center" bg="white" marginTop={"5px"} _text={{fontWeight: "medium",color: "warmGray.50",letterSpacing: "lg"}} style={{width:"95%"}}>
          <Image marginTop={4} source={require('../../../../src/images/EnfermedadesCronicas.png')} resizeMode={"contain"} size={"2xl"} alignSelf={"center"} alt="EnfermedadesCronicas"/>
            <Heading marginTop={4} textAlign="center" fontSize={"3xl"}>Registra todas aquellas enfermedades crónicas que posees.</Heading>
            <Form/>
            <Center>
              <Button  colorScheme="info" title='GUARDAR' onPress={()=>navigation.navigate('EnfermedadesCronicas')} style={{width:"85%"}} marginBottom={4}>GUARDAR</Button>
            </Center>
          </Box>
        </Box>
      </NativeBaseProvider>
    );
}