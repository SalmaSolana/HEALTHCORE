import React from 'react';
import { MaterialIcons } from '@expo/vector-icons'; 
import { FontAwesome } from '@expo/vector-icons'; 
import { AntDesign } from "@expo/vector-icons";
import { Ionicons } from '@expo/vector-icons'; 
import { TextInput,StyleSheet } from 'react-native';
import { VStack,HStack, IconButton, Icon, Text,NativeBaseProvider,Image, Input, Center, Box, StatusBar, Heading,Button} from "native-base";

const styles = StyleSheet.create({
  input:{
      height:120,
      width:300,
      borderWidth:1,
      padding:5,
      borderRadius:8,
  }
});

function AppBar() {
  return(<>
    <StatusBar bg="#3700B3" barStyle="light-content" />
    <Box safeAreaTop>
      <HStack bg="info.600" px="1" py="3" justifyContent="space-between" alignItems="center" w="100%">
        <HStack alignItems="center">
          <Text color="white" fontSize="45"  fontWeight="bold" style={{marginLeft:10}}>Enfermedades Cronicas</Text>
        </HStack>
        <HStack>
          <IconButton icon={<Icon as={MaterialIcons} name="more-vert" size="2xl" color="white" />} />
        </HStack>
      </HStack>
    </Box>
  </>);
}

  function Form(){
    return(<>
    <VStack space={4} alignItems="center" marginY={4}>
      <Input  placeholder={"Diabetes. Recién detectada hace 2 meses."}  w="85%" h="100" multiline bg={"lightBlue.200"} placeholderTextColor="black" fontSize={"2xl"}/>
      <Input  placeholder={" Cáncer de pulmón. Últimos meses de tratamiento."}  w="85%" h="100" multiline bg={"lightBlue.200"} placeholderTextColor="black" fontSize={"2xl"}/>
      <Input  placeholder={"Alzheimer. Nada grave.."}  w="85%" h="100" multiline bg={"lightBlue.200"} placeholderTextColor="black" fontSize={"2xl"}/>
      <Input  placeholder={"Diabetes. Recién detectada hace 2 meses."}  w="85%" h="100" multiline bg={"lightBlue.200"} placeholderTextColor="black" fontSize={"2xl"}/>
      </VStack></>
    );
  }

export default function EnfermedadesCronicasModificar({navigation}){
    return(
      <NativeBaseProvider>
        <AppBar/>
        <Box>
          <Box borderWidth={3} borderRadius="xl" borderColor="info.800" alignSelf="center" bg="white" marginTop={3} _text={{fontWeight: "medium",color: "warmGray.50",letterSpacing: "lg"}} style={{width:"95%"}}>
            <Image marginTop={4} source={require('../../../../src/images/EnfermedadesCronicas.png')} resizeMode={"contain"} size={"2xl"} alignSelf={"center"} alt="EnfermedadesCronicas"/>
            <Heading marginTop={4} textAlign="center" fontSize={"3xl"} >Enfermedades registradas del paciente.</Heading>
            <Form/>
            <Center>
              <Button  colorScheme="info" title='GUARDAR' onPress={()=>navigation.navigate('EnfermedadesCronicas')} style={{width:"85%"}} marginBottom={4} >GUARDAR</Button>
            </Center>
          </Box>
        </Box>
      </NativeBaseProvider>
    );
}