import React from 'react';
import { MaterialIcons } from '@expo/vector-icons'; 
import { FontAwesome } from '@expo/vector-icons'; 
import { AntDesign } from "@expo/vector-icons";
import { Ionicons } from '@expo/vector-icons'; 
import { VStack, Fab, HStack, IconButton, Icon, Text, NativeBaseProvider, Center, Box, StatusBar, Heading,Stack, Button, Image} from "native-base";

function AppBar() {
  return (<>
    <StatusBar bg="#3700B3" barStyle="light-content" />
    <Box safeAreaTop />
    <HStack bg="info.600" px="1" py="3" justifyContent="space-between" alignItems="center" w="100%">
      <HStack alignItems="center">
        <Text color="white" fontSize="40" fontWeight="bold" style={{marginLeft:10}}>Enfermedades Crónicas</Text>
      </HStack>
      <HStack>
        <IconButton icon={<Icon as={MaterialIcons} name="more-vert" size="xl" color="white" />} />
      </HStack>
    </HStack>
  </>);
}

  function Form(){
    return(<><VStack  alignItems="center">
        <Center w="100%" h="140px">
          <Stack alignItems="center">
            <HStack alignItems="center">
              <Center width={"80%"} height={"100%"} rounded="md">
                <Box borderRadius={9} bg="lightBlue.200" w={"90%"} h={"80%"}>
                  <Text fontWeight={"bold"} fontSize="lg" style={{ padding: 10 }}>
                    Diabetes. Recién detectada hace 2 meses.
                  </Text>
                </Box>
              </Center>
              <Center width={"10%"} height={"100%"} >
                <Icono />
              </Center>
            </HStack>
          </Stack>
        </Center>
        {/*NUMERO 2*/}
        <Center w="100%" h="140px">
          <Stack  alignItems="center">
            <HStack alignItems="center">
              <Center width={"80%"} height={"100%"} rounded="md">
                <Box borderRadius={9} bg="lightBlue.200" w={"90%"} h={"80%"}>
                  <Text fontWeight={"bold"} fontSize="lg" style={{ padding: 10 }}>
                  Cáncer de pulmón. Últimos meses de tratamiento.
                  </Text>
                </Box>
              </Center>
              <Center width={"10%"} height={"100%"} >
                <Icono />
              </Center>
            </HStack>
          </Stack>
        </Center>
        {/*NUMERO 3 */}
        <Center w="100%" h="140px">
          <Stack  alignItems="center">
            <HStack alignItems="center">
              <Center width={"80%"} height={"100%"} rounded="md">
                <Box borderRadius={9} bg="lightBlue.200" w={"90%"} h={"80%"}>
                  <Text fontWeight={"bold"} fontSize="lg" style={{ padding: 10 }}>
                  Alzheimer. Nada grave.
                  </Text>
                </Box>
              </Center>
              <Center width={"10%"} height={"100%"} >
                <Icono />
              </Center>
            </HStack>
          </Stack>
        </Center>
      </VStack></>
    );
  }
  
  const Icono = () => {
    return <Box alignItems="center">
        <IconButton icon={<Icon as={FontAwesome} name="trash-o" size={5} color="black"/>} borderRadius="full" _icon={{
        color: "red.400",
        size: "md"
      }} _hover={{
        bg: "red.400"
      }} _pressed={{
        bg: "red.400"
      }} />
      </Box>;
  };

  const NewButton = () => {
    return <Center>
        <Box width={"100%"} height={"90"} justifyContent={"flex-end"} _dark={{
        bg: "coolGray.200:alpha.20"
      }} _light={{
        bg: "coolGray.200:alpha.20"
      }}>
          <Fab renderInPortal={false} shadow={2} size="lg" icon={<Icon color="white" as={AntDesign} name="plus" size="lg" />} />
        </Box>
      </Center>;
  };
export default function EnfermedadesCronicas({navigation}){
    return(
      <NativeBaseProvider>
        <AppBar/>
        <Box>
          <Box borderWidth={3} borderRadius="xl" borderColor="info.800" alignSelf="center" bg="white" marginTop={4} paddingBottom={5} _text={{fontWeight: "medium",color: "warmGray.50",letterSpacing: "lg"}} style={{width:"95%"}}>
            <Image marginTop={4} source={require('../../../../src/images/EnfermedadesCronicas.png')} resizeMode={"contain"} size={"2xl"} alignSelf={"center"} alt="EnfermedadesCronicas"/>
            <Heading marginTop={4} textAlign="center" fontSize={"3xl"} >Enfermedades registradas del paciente.</Heading>
            <Form/>
            <Center>
              <Button  colorScheme="blue" title='MODIFICAR' onPress={()=>navigation.navigate('EnfermedadesCronicasModificar')} style={{width:"85%"}}>MODIFICAR</Button>
            </Center>
            <Fab
              active={true}
              direction="up"
              position={"absolute"}
              background="info.300"
              onPress={()=>navigation.navigate('EnfermedadesCronicasAlta')}
              icon={<Icon as={Ionicons} name="add" size={50} color="black"/>}>
            </Fab>
          </Box>
        </Box>
      </NativeBaseProvider>
    );
}