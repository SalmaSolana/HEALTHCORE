import React from 'react';
import { MaterialIcons } from '@expo/vector-icons'; 
import { FontAwesome } from '@expo/vector-icons';
import { AntDesign } from "@expo/vector-icons";
import { useNavigation } from '@react-navigation/native';
import { VStack,Fab, HStack,Heading, FormControl, Select, CheckIcon, Radio, Input, Button, IconButton, Icon, Text, NativeBaseProvider, Center, Box, StatusBar, Image } from "native-base";

function AppBar() {
  return(<>
    <StatusBar bg="#3700B3" barStyle="light-content" />
    <Box safeAreaTop>
      <HStack bg="info.600" px="1" py="3" justifyContent="space-between" alignItems="center" w="100%">
        <HStack alignItems="center">
          <Text color="white" fontSize="45"  fontWeight="bold" style={{marginLeft:10}}>Cirugias</Text>
        </HStack>
        <HStack>
          <IconButton icon={<Icon as={MaterialIcons} name="more-vert" size="2xl" color="white" />} />
        </HStack>
      </HStack>
    </Box>
  </>);
  }
  
function Cir(){
  const navigation = useNavigation();
  return(<>
    <Box borderWidth={3} borderRadius="xl"  borderColor="info.800" alignSelf="center"paddingTop={4} bg="white" marginTop={4} width="95%" h="90%">
      <Image source={require('../../../../src/images/Cirugias.png')} size="2xl" resizeMode='contain' alignSelf={"center"} alt={"Cirugias"}/>
      <Heading fontSize={"3xl"} textAlign="center" marginBottom={"30%"}>Cirugias Registradas</Heading>
      <Heading fontSize={"2xl"} fontStyle="italic" textAlign="center">Cirugías por las que se ha intervenido al paciente.</Heading>

      <VStack marginX={30} space={4}>
        {/*Cirugia*/}
        <HStack space={2} alignItems="center" marginTop={10}>
          <Text fontWeight={"bold"} fontSize="xl">Cirugía:</Text>
          <Input w="70%" h="100" isDisabled multiline numberOfLines={3} fontStyle={"italic"} bg={"lightBlue.200"}fontWeight={"bold"} color="black" fontSize={"2xl"}>Extracción de Vesicula Biliar</Input>
          <Icono/>
        </HStack>
        {/*Tipo */}
        <HStack space={2} alignItems={"center"}>
          <Text fontWeight={"bold"} fontSize="xl">Tipo:</Text>
          <FormControl w="30%">
            <Select accessibilityLabel="Choose Service" placeholder='Urgente' isDisabled fontWeight={"bold"} fontSize={"lg"} _selectedItem={{ bg: "black", endIcon: <CheckIcon size={3} /> }}>
              <Select.Item label="Programada" value="ux" />
              <Select.Item label="Urgente" value="web" />
              <Select.Item label="Ambulatoria" value="cross" />
            </Select>
          </FormControl>
        </HStack>
        {/*Fecha*/}
        <HStack alignItems={"center"}>
        <Text fontWeight={"bold"} w="30%" fontSize="xl">Fecha en que se realizó la cirugía:</Text>
          <Input w="30%" isDisabled bg={"lightBlue.200"} fontWeight={"bold"} color="black" fontSize={"2xl"}>02/04/2020</Input>
        </HStack>
        <Center>
        <Button backgroundColor="info.600" width="100%" h="20" title='MODIFICAR' onPress={()=>navigation.navigate('CirugiasModificar')}><Text fontSize={"3xl"} fontWeight="bold" color="white">MODIFICAR</Text></Button>
        </Center>
      </VStack>
      <Agregar/>
    </Box>
  </>);
}

const Icono = () => {
  return <Box alignItems="center">
      <IconButton icon={<Icon as={FontAwesome} name="trash-o" size={5} color="black"/>} borderRadius="full" _icon={{
      color: "red.400",
      size: "md"
    }} _hover={{
      bg: "red.400"
    }} _pressed={{
      bg: "red.400"
    }} />
    </Box>;
};

const Agregar = () => {
  const navigation = useNavigation();
  return <Center marginTop={1.45}>
      <Box width={"100%"} height={"90"} justifyContent={"flex-end"} _dark={{
      bg: "coolGray.200:alpha.20"
    }} _light={{
      bg: "coolGray.200:alpha.20"
    }}>
        <Fab renderInPortal={false} shadow={2} size="70" backgroundColor={"info.600"} onPress={()=>navigation.navigate('CirugiasAlta')} icon={<Icon color="white" as={AntDesign} name="plus" size="lg" />} />
      </Box>
    </Center>;
};

export default function Cirugias({navigation}){
  return(
    <NativeBaseProvider>
      <AppBar/>
      <Cir />
    </NativeBaseProvider>
  );
}