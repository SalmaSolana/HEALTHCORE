import React from 'react';
import { MaterialIcons } from '@expo/vector-icons'; 
import { FontAwesome } from '@expo/vector-icons';
import { AntDesign } from "@expo/vector-icons";
import { useNavigation } from '@react-navigation/native';
import { VStack,Fab, ScrollView, HStack,Heading, FormControl, Select, CheckIcon, Radio, Input, Button, IconButton, Icon, Text, NativeBaseProvider, Center, Box, StatusBar, Image } from "native-base";

function AppBar() {
    return(<>
      <StatusBar bg="#3700B3" barStyle="light-content" />
      <Box safeAreaTop>
        <HStack bg="info.600" px="1" py="3" justifyContent="space-between" alignItems="center" w="100%">
          <HStack alignItems="center">
            <Text color="white" fontSize="45"  fontWeight="bold" style={{marginLeft:10}}>Cirugias</Text>
          </HStack>
          <HStack>
            <IconButton icon={<Icon as={MaterialIcons} name="more-vert" size="2xl" color="white" />} />
          </HStack>
        </HStack>
      </Box>
    </>);
}

function Cir(){
    const navigation = useNavigation();
    const [value, setValue] = React.useState("one");
    const [value2, setValue2] = React.useState("two");
    return(<>
        <ScrollView>
            <Box borderWidth={3} borderRadius="xl"  borderColor="info.800" alignSelf="center"paddingTop={4} bg="white" marginTop={4} width="95%" paddingBottom={10}>
                <Image source={require('../../../../src/images/Cirugias.png')} size="2xl" resizeMode='contain' alignSelf={"center"} alt={"Cirugias"}/>
                <Heading fontSize={"3xl"} textAlign="center" marginBottom={"30%"}>Registro de Cirugías</Heading>
                <Heading fontSize={"2xl"} fontStyle="italic" textAlign="center">Registra aquellas cirugias por las que hayas sido intervenido</Heading>
            
                <VStack marginX={30} space={4}>
                    {/*Cirugia*/}
                    <HStack space={2} alignItems="center" marginTop={10}>
                        <Text fontWeight={"bold"} fontSize="xl">Cirugía:</Text>
                        <Input w="80%" h="100" multiline numberOfLines={3} fontStyle={"italic"} bg={"lightBlue.200"}fontWeight={"bold"} color="black" fontSize={"2xl"} placeholder="Describe aquí..."></Input>
                    </HStack>
                    {/*Tipo */}
                    <HStack space={2} alignItems={"center"}>
                        <Text fontWeight={"bold"} fontSize="xl">Tipo:</Text>
                        <FormControl w="55%">
                            <Select accessibilityLabel="Choose Service" placeholder='Selecciona una opción' fontWeight={"bold"} fontSize={"lg"} _selectedItem={{ bg: "black", endIcon: <CheckIcon size={3} /> }}>
                                <Select.Item label="Programada" value="ux" />
                                <Select.Item label="Urgente" value="web" />
                                <Select.Item label="Ambulatoria" value="cross" />
                            </Select>
                        </FormControl>
                    </HStack>
                    {/*Fecha*/}
                    <HStack alignItems={"center"}>
                        <Text fontWeight={"bold"} w="30%" fontSize="xl">Fecha en que se realizó la cirugía:</Text>
                        <Input w="40%" bg={"lightBlue.200"} fontWeight={"bold"} color="black" fontSize={"2xl"} placeholder={"DD/MM/AAAA"}></Input>
                    </HStack>
                    <Center>
                        <Button backgroundColor="info.600" width="100%" h="20" marginTop={5} onPress={()=>navigation.navigate('Cirugias')}><Text fontSize={"3xl"} fontWeight="bold" color="white">GUARDAR</Text></Button>
                    </Center>
                </VStack>
            </Box>
        </ScrollView>
    </>);
}

export default function CirugiasAlta({navigation}){
    return(
      <NativeBaseProvider>
        <AppBar/>
        <Cir/>
      </NativeBaseProvider>
    );
  }