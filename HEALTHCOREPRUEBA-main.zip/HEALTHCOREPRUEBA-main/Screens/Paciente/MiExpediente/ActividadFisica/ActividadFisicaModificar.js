import React from 'react';
import { useNavigation } from '@react-navigation/native';
import { MaterialIcons } from '@expo/vector-icons'; 
import { FontAwesome } from '@expo/vector-icons'; 
import { AntDesign } from "@expo/vector-icons";
import { VStack, Fab, HStack, IconButton, Input, Icon, Text, FormControl, CheckIcon, NativeBaseProvider, Center, Box, StatusBar, Heading, Select,Stack, Button, Image} from "native-base";

function AppBar() {
  return(<>
    <StatusBar bg="#3700B3" barStyle="light-content" />
    <Box safeAreaTop>
      <HStack bg="info.600" px="1" py="3" justifyContent="space-between" alignItems="center" w="100%">
        <HStack alignItems="center">
          <Text color="white" fontSize="45"  fontWeight="bold" style={{marginLeft:10}}>Actividad Física</Text>
        </HStack>
        <HStack>
          <IconButton icon={<Icon as={MaterialIcons} name="more-vert" size="2xl" color="white" />} />
        </HStack>
      </HStack>
    </Box>
  </>);
}

  function Form(){
    const navigation = useNavigation();
    return(<>
      <VStack space={5} marginTop={4} marginBottom={4} alignItems="center">
        <Center w="95%">
          <HStack space="2" alignItems="center">
            <Text  fontWeight={"bold"} fontSize="lg">Actividad:</Text>
            <Input fontWeight={"bold"} w={"75%"} h="100" multiline fontSize="xl" placeholder='Ingresa el tipo de ejercicio que realizas'></Input>
          </HStack>
        </Center>
        {/*NUMERO 2*/}
        <Center w="95%">
          <HStack space="2" alignItems="center">
            <Text fontWeight={"bold"} fontSize="lg">Duración:</Text>
            <Input w="75%" size="xl" fontWeight={"bold"} fontSize="xl" placeholder='Ingresa la duración de tu entrenamiento'></Input>
          </HStack>
        </Center>
        {/*NUMERO 3 */}
        <Center w="95%">
          <HStack space="2" alignItems="center">
            <Text fontWeight={"bold"} fontSize="lg">Frecuencia:</Text>
            <FormControl w="72%">
              <Select accessibilityLabel="Frecuencia" size="xl" placeholder="Frecuencia de tu entrenamiento" fontWeight={"bold"} _selectedItem={{ bg: "black", endIcon: <CheckIcon size={3} /> }}>
                <Select.Item label="Dos veces por semana" value="ux" />
                <Select.Item label="Tres o cuatro veces por semana" value="web" />
                <Select.Item label="Cinco o más veces por semana" value="cross" />
              </Select>
            </FormControl>
          </HStack>
        </Center>
        <Button w="95%" h="20" backgroundColor={"info.600"} marginTop={"10%"} title='GUARDAR' onPress={()=>navigation.navigate('ActividadFisica')}><Text fontSize={"3xl"} fontWeight="bold" color="white">GUARDAR</Text></Button>
      </VStack>
    </>);}

export default function ActividadFisicaModificar({navigation}){
    return(
      <NativeBaseProvider>
        <AppBar/>
        <Box>
          <Box borderWidth={3} borderRadius="xl" borderColor="info.800" alignSelf="center" bg="white" width={"95%"} h="94%" marginTop={4} _text={{fontWeight: "medium",color: "warmGray.50",letterSpacing: "lg"}} style={{width:"95%"}}>
            <Image source={require('../../../../src/images/ActividadFisica.png')} marginTop={4} size="2xl" alignSelf={"center"} alt={"Actividad Fisica"}/>
            <Heading fontSize={"3xl"} size="2xl" textAlign="center" marginBottom={"35%"}>Modificar Actividad Física.</Heading>
            <Heading fontSize={"2xl"} size="2xl" textAlign="center">Actividad física que realiza el paciente.</Heading>
            <Form/>
          </Box>
        </Box>
      </NativeBaseProvider>
    );
}