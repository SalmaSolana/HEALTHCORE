import React from 'react';
import useSyncExternalStore from 'react';
import {MaterialIcons} from '@expo/vector-icons';
import { HStack, IconButton, Icon, Text,Image, NativeBaseProvider, Center, Box, StatusBar} from "native-base";

  function AppBar() {
    return <>
        <StatusBar bg="#3700B3" barStyle="light-content" />
        <Box safeAreaTop bg="#6200ee" />
        <HStack bg="#6200ee" px="1" py="3" justifyContent="space-between" alignItems="center" w="100%">
          <HStack alignItems="center">
            <Text color="white" fontSize="20" fontWeight="bold" style={{marginLeft:10}}>Mi Código QR</Text>
          </HStack>
          <HStack>
            <IconButton icon={<Icon as={MaterialIcons} name="more-vert" size="sm" color="white" />} />
          </HStack>
        </HStack>
      </>;
  }

  function Form(){
  return(<><Box>
      <Center>
        
        <Image source={require('../../../src/images/qr.png')} style={{ width: 300, height: 300}}  />
        
      </Center>
    </Box>
  </>);}

export default function QR({navigation}){
  return(
    <NativeBaseProvider>
      <AppBar />
      <Center>
      <Text color="grey" fontSize="24" fontWeight="bold" style={{marginLeft:10}}>Expediente Digital Generado</Text>
      </Center>
        <Text  color="grey" fontSize="15" fontWeight="bold" style={{ marginLeft: 10 }}>
      </Text >
       <Box borderWidth={1} borderColor="light.400" alignSelf="center" bg="white" marginTop={"5px"} paddingBottom={"5px"} _text={{ fontWeight: "medium", color: "warmGray.50", letterSpacing: "lg" }} style={{ width: "85%" }}>
      <Form />
      </Box>
        <Text  color="grey" fontSize="15" fontWeight="bold" style={{ marginLeft: 10 }}>
      </Text >
      <HStack alignItems="center">
        <IconButton icon={<Icon as={MaterialIcons} name="report-problem" size="sm" color="yellow.100" />} />
        <Text color="grey"  fontSize="13" fontWeight="extrabold" >Tu código QR es personal, no lo compartas con nadie que no sea tu familia, persona cercana a ti, o al personal médico calificado.</Text> 
        </HStack>
    </NativeBaseProvider>
  );
}
